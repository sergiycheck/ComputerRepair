﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmapp
{
    public class ComputersOnRepairViewModel : INotifyPropertyChanged
    {


        public ObservableCollection<ItemModel> Computers { get; set; }
        public ComputersOnRepairViewModel()
        {
            Computers = new ObservableCollection<ItemModel>
            {
                new ItemModel { Title="Macbook", Company="Apple", Price=56000,ImagePath="C:/Users/sergi/source/repos/mvvmapp/mvvmapp/images/1.jpg" },
                new ItemModel {Title="Lenovo 330ich", Company="Lenovo", Price =60000,ImagePath="C:/Users/sergi/source/repos/mvvmapp/mvvmapp/images/2.jpg"},
            };
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}

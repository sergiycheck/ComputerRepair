﻿using mvvmApp.Bll.Infrastructure;
using mvvmApp.Bll.Intecation.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmapp.ViewModels
{
    public class UpdateViewModel : ActionsItemViewModel
    {


        private RelayCommand updateComputerCommand;
        public RelayCommand UpdateComputerCommand
        {
            get
            {
                if (updateComputerCommand != null)
                    return updateComputerCommand;
                else
                    return (updateComputerCommand = new RelayCommand(ob =>
                    {
                        serviceAdo.Items.Update(new mvvmApp.Dal.Abstract.Item()
                        {
                            Company = computer.Company,
                             Id = computer.Id,
                              ImagePath = computer.ImagePath,
                               Price = computer.Price,
                                Title = computer.Title
                        });
                    }
                    ));
            }
        }

        public UpdateViewModel(ItemModel updatedComputer)
        {
            serviceAdo = new ServiceModuleAdo();
            computer = updatedComputer;

            image = computer.ImagePath;
            company = computer.Company;
            title = computer.Title;
            price = computer.Price;
            id = computer.Id;

        }

    }
}

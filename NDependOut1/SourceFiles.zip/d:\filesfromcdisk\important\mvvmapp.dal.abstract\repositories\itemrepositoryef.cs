﻿using mvvmApp.Dal.Abstract.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmApp.Dal.Abstract.Repositories
{
    public class ItemRepositoryEF : IRepository<Item>
    {
        private ApplicationContext db;
        public ItemRepositoryEF(ApplicationContext context)
        {
            db = context;
        }
        public void Create(Item item)
        {
            db.Items.Add(item);
            Save();
        }

        public void Delete(int id)
        {
            Item item = db.Items.Find(id);
            db.Items.Remove(item);
            Save();
        }

        public IEnumerable<Item> GetAllItems()
        {
            return db.Items;
        }

        public Item GetItem(int id)
        {
            Item item = db.Items.Find(id);
            return item;
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public void Update(Item item)
        {
            db.Entry(item).State = System.Data.Entity.EntityState.Modified;
            Save();
        }
    }
}

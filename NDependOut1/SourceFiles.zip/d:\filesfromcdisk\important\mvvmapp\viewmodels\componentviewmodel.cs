﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmapp
{
    public class ComponentViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<ItemModel> Components { get; set; }
        public ComponentViewModel()
        {
            Components = new ObservableCollection<ItemModel>
            {
                new ItemModel { Title="video card", Company="Msi", Price=1600,ImagePath=@"D:\filesFromCDisk\important\mvvmapp\Resources2.1.jpg" },
                new ItemModel {Title="Processor inter core i9", Company="Intel", Price =1000,ImagePath=@"D:\filesFromCDisk\important\mvvmapp\Resources2.2.png"},
                new ItemModel {Title="Mother board", Company="Msi", Price=1200,ImagePath=@"D:\filesFromCDisk\important\mvvmapp\Resources2.3.png" },
                new ItemModel {Title="MSI monitor", Company="Msi", Price=1350,ImagePath=@"D:\filesFromCDisk\important\mvvmapp\Resources2.4.jpg" },
                new ItemModel {Title="key board", Company="Samsund", Price=150,ImagePath=@"D:\filesFromCDisk\important\mvvmapp\Resources2.5.jpg" }
            };
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyRaised(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }
    }
}

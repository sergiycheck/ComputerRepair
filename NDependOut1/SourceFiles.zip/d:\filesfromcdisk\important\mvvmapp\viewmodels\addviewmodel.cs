﻿using mvvmApp.Bll.Infrastructure;
using mvvmApp.Bll.Intecation.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmapp.ViewModels
{
    public class AddViewModel : ActionsItemViewModel
    {

        private RelayCommand addComputerCommand;
        public RelayCommand AddComputerCommand
        {
            get
            {
                if (addComputerCommand != null)
                    return addComputerCommand;
                else
                    return (addComputerCommand = new RelayCommand(ob =>
                    {

                        serviceAdo.Items.Create(new mvvmApp.Dal.Abstract.Item()
                        {
                                Company = computer.Company,
                                Title = computer.Title,
                                ImagePath = computer.ImagePath,
                                Price = computer.Price
                        });
                        

                    }
                    ));
            }
        }

        public AddViewModel()
        {
            serviceAdo = new ServiceModuleAdo();
            computer = new ItemModel();
        }


    }
}

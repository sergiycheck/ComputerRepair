﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mvvmApp.Dal.Abstract.Entities.Components
{
    public class MemoryModule:Element
    {

        public string MemoryType { get; set; }//ddr4
        
    }
}

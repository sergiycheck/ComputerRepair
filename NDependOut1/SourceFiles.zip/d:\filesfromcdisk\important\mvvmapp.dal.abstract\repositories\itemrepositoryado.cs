﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows;

namespace mvvmApp.Dal.Abstract.Repositories
{
    public class ItemRepositoryADO : IRepository<Item>
    {
        readonly string connectionString;
        SqlDataAdapter adapter;
        DataTable itemsTable;


        public ItemRepositoryADO()
        {
            connectionString = ConfigurationManager.ConnectionStrings["MvvmAppDb"].ConnectionString;
            
        }
        #region
        //private void ExecuteQuery(string sqlQuery)
        //{
        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        conn.Open();
        //        SqlCommand comm = new SqlCommand(sqlQuery, conn);
        //        int num = comm.ExecuteNonQuery();
        //        comm.Dispose();
        //        if (conn != null)
        //            conn.Close();
        //        if(itemsTable!=null)
        //            itemsTable.Clear();
        //    }
        //}
        #endregion
        public void Create(Item item)
        {
            //ExecuteQuery(sqlQuery);
            string sqlQueryParametrized =
                "Insert into Items (Title,ImagePath,Price,Company)" +
                "Values (@Title,@ImagePath,@Price,@Company)";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(sqlQueryParametrized, conn);
                SqlParameter titleParam = new SqlParameter("@Title", item.Title);
                comm.Parameters.Add(titleParam);
                SqlParameter ImagePathParam = new SqlParameter("@ImagePath", item.ImagePath);
                comm.Parameters.Add(ImagePathParam);
                SqlParameter PriceParam = new SqlParameter("@Price", item.Price);
                comm.Parameters.Add(PriceParam);
                SqlParameter CompanyParam = new SqlParameter("@Company", item.Company);
                comm.Parameters.Add(CompanyParam);

                int num = comm.ExecuteNonQuery();
                comm.Dispose();
                if (conn != null)
                    conn.Close();
            }
        }
        
        public void Delete(int id)
        {
            string sqlQuery =
                "Delete from Items " +
                "Where id = @Id";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(sqlQuery, conn);
                SqlParameter idParam = new SqlParameter("@Id",id);
                comm.Parameters.Add(idParam);

                int num = comm.ExecuteNonQuery();
                comm.Dispose();
                if (conn != null)
                    conn.Close();
            }
        }

        public IEnumerable<Item> GetAllItems()
        {
            string sql = "Select * from Items";
            itemsTable = new DataTable();
            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand command = new SqlCommand(sql, connection);
            adapter = new SqlDataAdapter(command);

            connection.Open();
            adapter.Fill(itemsTable);

            var result = new List<Item>();
            foreach(DataRow row in itemsTable.Rows)
            {
                var el = new Item
                {
                    Company = row["Company"].ToString(),
                    ImagePath = row["ImagePath"].ToString(),
                    Title = row["Title"].ToString(),
                    Price = Convert.ToInt32(row["Price"]),
                    Id = Convert.ToInt32(row["Id"])
                };
                result.Add(el);
            }
            if (connection != null)
                connection.Close();

            return result;
        }
        public async Task<IEnumerable<Item>> GetAllItemsAsync()
        {
            string sql = "Select * from Items";
            itemsTable = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                adapter = new SqlDataAdapter(command);

                await connection.OpenAsync();
                adapter.Fill(itemsTable);

                var result = new List<Item>();
                foreach (DataRow row in itemsTable.Rows)
                {
                    var el = new Item
                    {
                        Company = row["Company"].ToString(),
                        ImagePath = row["ImagePath"].ToString(),
                        Title = row["Title"].ToString(),
                        Price = Convert.ToInt32(row["Price"]),
                        Id = Convert.ToInt32(row["Id"])
                    };
                    result.Add(el);
                }
                if (connection != null)
                    connection.Close();
                return result;
            }
         
        }

        public Item GetItem(int id)
        {
            string sql = "Select * from Items " +
                "where id = @Id";

            itemsTable = new DataTable();
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sql, connection);
                SqlParameter idParam = new SqlParameter("@Id", id);
                command.Parameters.Add(idParam);
                adapter = new SqlDataAdapter(command);

                connection.Open();

                adapter.Fill(itemsTable);
                var res = new Item();
                foreach (DataRow row in itemsTable.Rows)
                {
                    var el = new Item
                    {
                        Company = row["Company"].ToString(),
                        ImagePath = row["ImagePath"].ToString(),
                        Title = row["Title"].ToString(),
                        Price = Convert.ToInt32(row["Price"]),
                        Id = Convert.ToInt32(row["Id"])
                    };
                    res = el;
                }
                connection.Close();
                return res;
            }


        }

        public void Save()
        {
            //string query = "Begin Transaction commit";
            //ExecuteQuery(query);
            
        }

        public void Update(Item item)
        {


            string sqlQueryParam = 
                "Update Items" +
                "Set" +
                "Title = @Title," +
                "ImagePath = @ImagePath," +
                "Price = @ImagePath," +
                "Company = @Company," +
                "Where Id = @Id";
            
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand(sqlQueryParam, conn);

                SqlParameter titleParam = new SqlParameter("@Title", item.Title);
                comm.Parameters.Add(titleParam);
                SqlParameter ImagePathParam = new SqlParameter("@ImagePath", item.ImagePath);
                comm.Parameters.Add(ImagePathParam);
                SqlParameter PriceParam = new SqlParameter("@Price", item.Price);
                comm.Parameters.Add(PriceParam);
                SqlParameter CompanyParam = new SqlParameter("@Company", item.Company);
                comm.Parameters.Add(CompanyParam);
                SqlParameter idParam = new SqlParameter("@Id",item.Id);
                comm.Parameters.Add(idParam);



                int num = comm.ExecuteNonQuery();
                comm.Dispose();
                if (conn != null)
                    conn.Close();
                if (itemsTable != null)
                    itemsTable.Clear();
            }
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Linq.Mapping;

namespace mvvmApp.Dal.Abstract
{
    [Table(Name = "Orders")]
    public class Order
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true, Name ="Id")]
        public int Id { get; set; }

        [Column(Name ="Sum")]
        public decimal Sum { get; set; }

        [Column(Name = "PhoneNumber")]
        public string PhoneNumber { get; set; }

        [Column(Name = "Address")]
        public string Address { get; set; }

        [Column(Name = "Date")]
        public DateTime Date { get; set; }

        public List<Item> OrderedComputers { get; set; }
    }
}
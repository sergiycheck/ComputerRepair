﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using mvvmApp.Bll.Intecation.Commands;
using mvvmApp.Dal.Abstract.Entities;
using mvvmApp.Dal.Abstract.Repositories;
using mvvmapp.Models;

namespace mvvmapp.ViewModels
{
    public class LoginViewModel:UserModel
    {
        private RelayCommand loginCommand;

        public RelayCommand LoginCommand
        {
            get
            {
                if (loginCommand != null)
                    return loginCommand;
                else
                    return (loginCommand = new RelayCommand(ob =>
                    {
                        User model = new User()
                        {
                            Address = "Yangelya",
                            Password = Password,
                            PhoneNumber = PhoneNumber,
                            Name = "Serhii"

                        };
                        UserRepository<User> repository = new UserRepository<User>(new ApplicationContext("mvvmApp.Dal.Abstract.Entities.ApplicationContext"));
                        bool res = repository.Verify(model);
                    }));
            }
        }
    }
}
